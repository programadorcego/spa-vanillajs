<?php
header("Content-Type: application/json; charset-utf-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");

require "../lib/database.php";

try
{
	$db = new Database();
	$categories = $db->select("categories");
	
	echo json_encode([
		"status" => "success",
		"categories" => $categories,
	]);
} catch(Exception $e)
	{
		$response = [
			"status" => "error",
			"message" => $e->getMessage(),
		];
		
		echo json_encode($response);
	}