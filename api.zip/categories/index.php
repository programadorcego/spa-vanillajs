<?php
header("Content-Type: application/json; charset-utf-8");

require "../lib/database.php";

try
{
	$db = new Database();
	$categories = $db->select("categories");
	
	echo json_encode([
		"status" => "success",
		"categories" => $categories,
	]);
} catch(Exception $e)
	{
		$response = [
			"status" => "error",
			"message" => $e->getMessage(),
		];
		
		echo json_encode($response);
	}