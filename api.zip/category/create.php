<?php
header("Content-Type: application/json; charset=utf-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

require "../lib/database.php";

try
{
    if($_SERVER["REQUEST_METHOD"] !== "POST")
    {
        throw new Exception("O método de requisição deve ser PUT.");
    }
    
    $fields = json_decode(file_get_contents("php://input"), true);
    
    $db = new Database();
    $category = $db->insert(table: "categories", fields: $fields);
    
    echo json_encode([
        "status" => "success",
        "category" => $category,
    ]);
} catch(Exception $e)
    {
        $response = [
            "status" => "error",
            "code" => $e->getCode(),
            "message" => $e->getMessage(),
        ];
        
        echo json_encode($response);
    }