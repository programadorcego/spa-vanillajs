<?php
header("Content-Type: application/json; charset=utf-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

require "../lib/database.php";

try
{
    if($_SERVER["REQUEST_METHOD"] !== "PUT")
    {
        throw new Exception("O método de requisição deve ser PUT.");
    }
    
    $id = $_GET["id"] ?? null;
    
    if(!$id)
    {
        throw new Exception("O parâmetro `id` é obrigatório");
    }
    
    $fields = json_decode(file_get_contents("php://input"), true);
    $db = new Database();
    $category = $db->update(table: "categories", fields: $fields, id: $id);
    
    echo json_encode([
        "status" => "success",
        "category" => $category,
    ]);
} catch(Exception $e)
    {
        $response = [
            "status" => "error",
            "code" => $e->getCode(),
            "message" => $e->getMessage(),
        ];
        
        echo json_encode($response);
    }