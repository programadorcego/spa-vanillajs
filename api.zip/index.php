<?php
header("Content-Type: application/json; charset=utf-8");

$data = json_decode(file_get_contents("php://input"), true);
$num1 = $data["num1"];
$num2 = $data["num2"];

echo json_encode([
	"adicao" => $num1 + $num2,
	"subtracao" => $num1 - $num2,
	"multiplicacao" => $num1 * $num2,
	"divisao" => $num1 / $num2,
]);