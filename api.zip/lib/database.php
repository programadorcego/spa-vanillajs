<?php
require "config.php";

class Database
{
	private $pdo;
	
	public function __construct()
	{
		try
		{
			$this->pdo = new PDO("mysql:host=".DB_HOST."; dbname=".DB_NAME."; charset=utf8", DB_USER, DB_PASSWORD, [
				PDO::ATTR_PERSISTENT => true,
				PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
				PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_OBJ,
			]);
		} catch(PDOException $e)
			{
				return throw new Exception($e->getMessage(), (int) $e->getCode());
			}
	}
	
	public function select($table, $fields = "*", $where = null)
	{
		$fields = is_array($fields) ? implode(", ", $fields) : $fields;
		$sql = "SELECT {$fields} FROM {$table}";
		
		if($where)
		{
			$sql .= " WHERE $where";
		}
		
		try
		{
			$stmt = $this->pdo->prepare($sql);
			$stmt->execute();
			
			return $stmt->fetchAll();
		} catch(PDOException $e)
			{
				return throw new Exception($e->getMessage(), (int) $e->getCode());
			}
	}
}