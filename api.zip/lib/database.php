<?php
require "config.php";

class Database
{
    private $pdo;
    
    public function __construct()
    {
        try
        {
            $this->pdo = new PDO("mysql:host=".DB_HOST."; dbname=".DB_NAME."; charset=utf8", DB_USER, DB_PASSWORD, [
                PDO::ATTR_PERSISTENT => true,
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_OBJ,
            ]);
        } catch(PDOException $e)
            {
                return throw new Exception($e->getMessage(), (int) $e->getCode());
            }
    }
    
    public function select($table, $fields = "*", $where = null)
    {
        $fields = is_array($fields) ? implode(", ", $fields) : $fields;
        $sql = "SELECT {$fields} FROM {$table}";
        
        if($where)
        {
            $sql .= " WHERE $where";
        }
        
        try
        {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute();
            
            return $stmt->fetchAll();
        } catch(PDOException $e)
            {
                return throw new Exception($e->getMessage(), (int) $e->getCode());
            }
    }
    
    public function update($table, array $fields, int $id)
    {
        $field_string = implode(", ", array_map(fn($k) => "$k = ?", array_keys($fields)));
        $values = array_values($fields);
        $values[] = $id;
        
        $sql = "UPDATE {$table} SET {$field_string} WHERE id = ?";
        
        try
        {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($values);
            
            $fields["updated_at"] = date("Y-m-d H:i:s");
            return (object) $fields;
        } catch(PDOException $e)
            {
                return throw new Exception($e->getMessage(), (int) $e->getCode());
            }
    }
    
    public function insert(string $table, array $fields)
    {
        try
        {
            $keys = implode(", ", array_keys($fields));
            $values = array_values($fields);
            $bind = implode(", ", array_fill(0, count($values), "?"));
            
            $sql = "INSERT INTO {$table} ({$keys}) VALUES ({$bind})";
            $stmt = $this->pdo->prepare($sql);
            $result = $stmt->execute($values);
            $fields["id"] = $this->pdo->lastInsertId();
            $fields["created_at"] = date("Y-m-d H:i:s");
            
            return (object) $fields;
        } catch(PDOException $e) {
            return throw new Exception($e->getMessage());
        }
    }
}