<?php
header("Content-Type: application/json; charset=utf-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

require "../lib/database.php";

try
{
    if($_SERVER["REQUEST_METHOD"] !== "POST")
    {
        throw new Exception("O método de requisição deve ser PUT.");
    }
    
    $fields = ["name" => $_POST["name"], "category_id" => (int) $_POST["category_id"]];
    
    $db = new Database();
    $post = $db->insert(table: "posts", fields: $fields);
    
    echo json_encode([
        "status" => "success",
        "post" => $post,
    ]);
} catch(Exception $e)
    {
        $response = [
            "status" => "error",
            "code" => $e->getCode(),
            "message" => $e->getMessage(),
        ];
        
        echo json_encode($response);
    }