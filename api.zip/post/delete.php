<?php
header("Content-Type: application/json; charset=utf-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: DELETE");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

require "../lib/database.php";

try
{
    if($_SERVER["REQUEST_METHOD"] !== "DELETE")
    {
        throw new Exception("O método de requisição deve ser DELETE.");
    }
    
    $id = $_GET["id"] ?? null;
    
    if(!$id)
    {
        throw new Exception("O parâmetro `id` é obrigatório");
    }
    
    $db = new Database();
    $delete = $db->delete(table: "posts", id: $id);
    
    echo json_encode([
        "status" => "success",
        "message" => "Category has been removed",
    ]);
} catch(Exception $e)
    {
        $response = [
            "status" => "error",
            "code" => $e->getCode(),
            "message" => $e->getMessage(),
        ];
        
        echo json_encode($response);
    }