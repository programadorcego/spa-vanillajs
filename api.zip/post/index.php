<?php
header("Content-Type: application/json; charset=utf-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");

require "../lib/database.php";

try
{
	$id = $_GET["id"] ?? null;
	
	if(!$id)
	{
		throw new Exception("O parâmetro `id` é obrigatório");
	}
	
	$db = new Database();
	$post = $db->select(table: "posts", where: "`id` = $id LIMIT 1");
	
	echo json_encode([
		"status" => "success",
		"post" => $post[0],
	]);
} catch(Exception $e)
	{
		$response = [
			"status" => "error",
			"code" => $e->getCode(),
			"message" => $e->getMessage(),
		];
		
		echo json_encode($response);
	}