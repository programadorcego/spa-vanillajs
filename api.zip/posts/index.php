<?php
header("Content-Type: application/json; charset=utf-8");

require "../lib/database.php";

try
{
	$category_id = $_GET["category_id"] ?? null;
	
	if(!$category_id)
	{
		throw new Exception("O parâmetro category_id é obrigatório");
	}
	
	$db = new Database();
	$posts = $db->select(fields: "p.id, p.name, c.name AS category", table: "posts AS p INNER JOIN categories AS c ON c.id = p.category_id", where: "p.category_id = $category_id");
	
	echo json_encode([
		"status" => "success",
		"posts" => $posts,
	]);
} catch(Exception $e)
	{
		$response = [
			"status" => "error",
			"message" => $e->getMessage(),
		];
		
		echo json_encode($response);
	}